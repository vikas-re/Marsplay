//
//  WebCommunicationClass.swift
//  HolaHotel
//
//  Created by Test on 4/18/16.
//  Copyright © 2016 DreamSoft4u. All rights reserved.
//

import Alamofire
import SVProgressHUD

@objc protocol WebCommunicationClassDelegate
{
    @objc optional func dataDidFinishDowloading (aResponse : AnyObject?, methodname : String) -> (Void)
    @objc optional func dataDidFail (methodname : String , error : Error) -> (Void)
}

class WebCommunicationClass: NSObject
{
    var aCaller: AnyObject?;
    var delegate: WebCommunicationClassDelegate?
    var blanckDict = NSMutableDictionary()

    //MARK:- User Authentication APIs
    func getListing(currentPageNum: Int) -> Void
    {
        if currentPageNum == 1
        {
            SVProgressHUD.show()
            SVProgressHUD.setDefaultMaskType(.gradient)
            AlamofireSyncWithGet(pageNum: currentPageNum)
        }
        else
        {
            AlamofireSyncWithGet(pageNum: currentPageNum)
        }
    }

    //MARK:- Server Response Methods
    func AlamofireSyncWithGet(pageNum: Int)
    {
        let finalURL = "\(serverURL)&page=\(pageNum)"
        let url = URL.init(string: finalURL)
        print("API URL: \(finalURL)")

        Alamofire.request(url!, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil).responseJSON { response in

            switch response.result
            {
            case .success(_):
                    if response.data != nil
                    {
                        SVProgressHUD.dismiss()
                        (self.aCaller?.dataDidFinishDowloading!(aResponse: response.data as AnyObject, methodname: ""))!
                    }
            case .failure(_):
                SVProgressHUD.dismiss()
                (self.aCaller?.dataDidFail!(methodname: "", error: response.error!))
                print("Error: " + (response.error!.localizedDescription))
                break
            }
        }
    }
}
