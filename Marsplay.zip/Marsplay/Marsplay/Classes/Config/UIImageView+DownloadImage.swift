//
//  UIImageView+DownloadImage.swift
//  Beeland_Artisan
//
//  Created by LS on 11/01/17.
//  Copyright © 2017 LS. All rights reserved.
//

import Foundation
import UIKit

extension UIImageView
{
    func imageForUrlWithImage(imageURL: String, defaultImage: String, imageID: String)
    {
        if imageURL == ""
        {
            self.image = UIImage(named: defaultImage)
        }
        else
        {
            let imagePath = (AppDel.getDirectoryPath() as NSString).appendingPathComponent(imageID)

            let fileManager = FileManager.default
            if fileManager.fileExists(atPath: imagePath)
            {
                self.image = UIImage(contentsOfFile: imagePath)
            }
            else
            {
                let indicater = UIActivityIndicatorView(style: UIActivityIndicatorView.Style.gray)
                indicater.color = UIColor.black
                indicater.frame = CGRect(x: self.frame.size.width/2 - 10, y: self.frame.size.height/2 - 10, width: 20, height: 20)
                self.addSubview(indicater)
                indicater.startAnimating()

                DispatchQueue.global(qos: .background).async {
                    let downloadTask  = URLSession.shared.dataTask(with: URL(string: imageURL)!, completionHandler: { (data: Data?, response: URLResponse?,error: Error?) in
                        if (error != nil)
                        {
                            return
                        }
                        
                        if data != nil
                        {
                            let image = UIImage(data: data!)
                            let paths = (AppDel.getDirectoryPath() as NSString).appendingPathComponent(imageID)
                            let fileManager = FileManager.default
                            fileManager.createFile(atPath: paths as String, contents: data, attributes: nil)
                            
                            DispatchQueue.main.async(execute: {() in
                                self.image = image
                                indicater.stopAnimating()
                            })
                            return
                        }
                    })
                    
                    downloadTask.resume()
                }
            }
        }
    }
}
