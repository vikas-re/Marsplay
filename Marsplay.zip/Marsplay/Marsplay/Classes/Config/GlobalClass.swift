//
//  GlobalClass.swift
//  Gigger
//
//  Created by LogicSpice on 24/09/18.
//  Copyright © 2018 logicspice. All rights reserved.
//

import Foundation

class GlobalClass
{
    static let sharedinstance = GlobalClass()
}


