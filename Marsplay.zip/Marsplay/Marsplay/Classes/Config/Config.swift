//
//  Config.swift
//  Gigger
//
//  Created by LogicSpice on 24/09/18.
//  Copyright © 2018 logicspice. All rights reserved.
//

import Foundation
import UIKit

enum alertType
{
    case okAlert
    case okAlertwithDelegate
    case YNAlert
    case YNClickAlert
    case OkCancelAlert
    case customBtnAlert
}

let window_Width = UIScreen.main.bounds.size.width
let window_Height = UIScreen.main.bounds.size.height
let AppDel = UIApplication.shared.delegate as! AppDelegate
let Global = GlobalClass.sharedinstance
let charSet = CharacterSet.whitespacesAndNewlines

let AppName = "Marsplay"
let serverURL = "http://www.omdbapi.com/?s=Batman&apikey=eeefc96f"

//MARK:- Messages
let ErrorMsg = "No Internet Connection"
let ServerErrorMsg = "There seems to be some problem either with your connection or our server, please try again."
let InvalidResMsg = "Invalid Server Response"
