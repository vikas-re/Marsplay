//
//  AlertControl.swift
//  Beeland_Artisan
//
//  Created by LS on 09/01/17.
//  Copyright © 2017 LS. All rights reserved.
//

import UIKit

@objc protocol alertClassDelegate
{
    @objc optional func alertYesClick()
    @objc optional func alertNoClick()
    @objc optional func alertOkClick()
}

class AlertControl: NSObject
{
    var  appdel = AppDel
    
    func AlertViewOk(msg:String)
    {
        let alert =   UIAlertController(title: AppName, message: NSLocalizedString(msg, comment: ""), preferredStyle: UIAlertController.Style.alert)
        
        let okAction = UIAlertAction(title:NSLocalizedString("OK", comment: ""), style: UIAlertAction.Style.default)
        { (action: UIAlertAction) in
            alert.dismiss(animated: true, completion: nil)
        }
        
        alert.addAction(okAction)
        appdel.appNav?.present(alert, animated: true, completion: nil)
    }
    
    func AlertViewOkWithDelegate(msg:String, delegate: AnyObject?)
    {
        let alert =   UIAlertController(title: AppName, message: NSLocalizedString(msg, comment: ""), preferredStyle: UIAlertController.Style.alert)
        
        let okAction = UIAlertAction(title:  NSLocalizedString("OK", comment: ""), style: UIAlertAction.Style.default) { (action: UIAlertAction) in
            
            if let delegate1 = delegate{
                delegate1.alertOkClick!()
            }
            alert.dismiss(animated: true, completion: nil)
            
        }
        
        alert.addAction(okAction)
        appdel.appNav?.present(alert, animated: true, completion: nil)
    }

    
    func AlertViewYClickNO(msg:String, delegate: AnyObject?)
    {
        let alert =   UIAlertController(title: AppName, message: NSLocalizedString(msg, comment: ""), preferredStyle: UIAlertController.Style.alert)
        
        let yesAction = UIAlertAction(title: NSLocalizedString("Yes", comment: ""), style: UIAlertAction.Style.default) { (action: UIAlertAction) in
            
            if let delegate1 = delegate{
                delegate1.alertYesClick!()
            }
            alert.dismiss(animated: true, completion: nil)
        }
        
        let noAction = UIAlertAction(title: NSLocalizedString("No", comment: ""), style: UIAlertAction.Style.default)
        { (action: UIAlertAction) in
            alert.dismiss(animated: true, completion: nil)
        }
        
        alert.addAction(yesAction)
        alert.addAction(noAction)
        appdel.appNav?.present(alert, animated: true, completion: nil)
    }
    
    func AlertViewYNClick(msg:String, delegate: AnyObject?)
    {
        let alert =   UIAlertController(title: AppName, message: NSLocalizedString(msg, comment: ""), preferredStyle: UIAlertController.Style.alert)
        
        let yesAction = UIAlertAction(title: NSLocalizedString("Yes", comment: ""), style: UIAlertAction.Style.default) { (action: UIAlertAction) in
            
            if let delegate1 = delegate{
                delegate1.alertYesClick!()
            }
            alert.dismiss(animated: true, completion: nil)
        }
        
        let noAction = UIAlertAction(title: NSLocalizedString("No", comment: ""), style: UIAlertAction.Style.default)
        { (action: UIAlertAction) in
            if let delegate1 = delegate{
                delegate1.alertNoClick!()
            }
            alert.dismiss(animated: true, completion: nil)
        }
        
        alert.addAction(yesAction)
        alert.addAction(noAction)
        appdel.appNav?.present(alert, animated: true, completion: nil)
    }
    
    func AlertViewOKCancel(msg:String, delegate: AnyObject?)
    {
        let alert =   UIAlertController(title: AppName, message: NSLocalizedString(msg, comment: ""), preferredStyle: UIAlertController.Style.alert)
        
        let yesAction = UIAlertAction(title: NSLocalizedString("OK", comment: ""), style: UIAlertAction.Style.default) { (action: UIAlertAction) in
            
            if let delegate1 = delegate{
                delegate1.alertYesClick!()
            }
            alert.dismiss(animated: true, completion: nil)
        }
        
        let noAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: UIAlertAction.Style.default)
        { (action: UIAlertAction) in
            alert.dismiss(animated: true, completion: nil)
        }
        
        alert.addAction(yesAction)
        alert.addAction(noAction)
        appdel.appNav?.present(alert, animated: true, completion: nil)
    }
    
    func AlertViewWithSettingDelegate(msg:String, delegate: AnyObject?, btnText:String)
    {
        let alert =   UIAlertController(title: AppName, message: NSLocalizedString(msg, comment: ""), preferredStyle: UIAlertController.Style.alert)
        
        let okAction = UIAlertAction(title:  NSLocalizedString(btnText, comment: ""), style: UIAlertAction.Style.default) { (action: UIAlertAction) in
            
            if let delegate1 = delegate{
                delegate1.alertOkClick!()
            }
            alert.dismiss(animated: true, completion: nil)
            
        }
        
        alert.addAction(okAction)
        appdel.appNav?.present(alert, animated: true, completion: nil)
    }
    
    func AlertWithCustomBtnDelegate(msg:String, delegate: AnyObject?, btnText:String)
    {
        let alert =   UIAlertController(title: AppName, message: NSLocalizedString(msg, comment: ""), preferredStyle: UIAlertController.Style.alert)
        
        let okAction = UIAlertAction(title:  NSLocalizedString(btnText, comment: ""), style: UIAlertAction.Style.default) { (action: UIAlertAction) in
            
            if let delegate1 = delegate{
                delegate1.alertOkClick!()
            }
            alert.dismiss(animated: true, completion: nil)
        }
        let noAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: UIAlertAction.Style.default)
        { (action: UIAlertAction) in
            alert.dismiss(animated: true, completion: nil)
        }
        
        alert.addAction(okAction)
        alert.addAction(noAction)
        appdel.appNav?.present(alert, animated: true, completion: nil)
    }
}

extension UIViewController
{
    func alertType(type:alertType,alertMSG:String,delegate:AnyObject,btntitle:String) -> Void
    {
        let alert = AlertControl()
        switch type
        {
        case .okAlert:
                alert.AlertViewWithSettingDelegate(msg: alertMSG, delegate: delegate, btnText: btntitle)
        
        case .customBtnAlert:
            alert.AlertWithCustomBtnDelegate(msg: alertMSG, delegate: delegate, btnText: btntitle)
        default:
            break
        }        
    }
    
    func alertType(type:alertType,alertMSG:String,delegate:AnyObject) -> Void
    {
        let alert = AlertControl()
        
        switch type
        {
        case .okAlert:
            alert.AlertViewOk(msg: alertMSG)
        case .okAlertwithDelegate:
            alert.AlertViewOkWithDelegate(msg: alertMSG, delegate: delegate)
        case .YNAlert:
            alert.AlertViewYClickNO(msg: alertMSG, delegate: delegate)
        case .YNClickAlert:
            alert.AlertViewYNClick(msg: alertMSG, delegate: delegate)
        case .OkCancelAlert:
            alert.AlertViewOKCancel(msg: alertMSG, delegate: delegate)
        default:
            break
        }
    }
}

