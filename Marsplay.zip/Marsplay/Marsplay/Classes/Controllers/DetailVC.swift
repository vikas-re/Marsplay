//
//  DetailVC.swift
//  Marsplay
//
//  Created by logicspice on 05/10/18.
//  Copyright © 2018 Vikas Sharma. All rights reserved.
//

import UIKit

class DetailVC: UIViewController
{
    //MARK:- Outlets
    @IBOutlet var imgPoster: UIImageView!
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var lblType: UILabel!
    @IBOutlet var lblReleaseDate: UILabel!

    //MARK:- Variables
    var dicData: NSDictionary!
    var releaseYear: String!

    //MARK:- View Life Cycle
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

        imgPoster.imageForUrlWithImage(imageURL: "\(dicData.object(forKey: "Poster")!)", defaultImage: "NoImage", imageID: "\(dicData.object(forKey: "imdbID")!)")
        lblTitle.text = "\(dicData.object(forKey: "Title")!)"
        lblType.text = "\(dicData.object(forKey: "Type")!)"
        lblReleaseDate.text = releaseYear
    }

    //MARK:- Button Action Methods
    @IBAction func action_btnBack(_ sender: UIButton)
    {
        self.navigationController?.popViewController(animated: true)
    }
}
