//
//  StartVC.swift
//  Marsplay
//
//  Created by logicspice on 05/10/18.
//  Copyright © 2018 Vikas Sharma. All rights reserved.
//

import UIKit

class DataCell: UICollectionViewCell
{
    @IBOutlet var imgPoster: UIImageView!
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var lblType: UILabel!
    @IBOutlet var lblYear: UILabel!

    override func awakeFromNib()
    {
        super.awakeFromNib()
    }
}

class StartVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, alertClassDelegate, WebCommunicationClassDelegate
{
    //MARK:- Outlets
    @IBOutlet var col_data: UICollectionView!
    @IBOutlet var btnRetry: UIButton!
    @IBOutlet var lblMsg: UILabel!

    //MARK:- Variables
    var arrData = NSMutableArray()
    var currentPage: Int = 1
    var totalCount: Int!
    var isWaiting: Bool = false
    var currentYear: Int!

    //MARK:- View Life Cycle
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy"
        currentYear = Int(dateFormatter.string(from: Date()))

        self.getData()
    }

    func changeYeartoTime(strYear: String) -> String
    {
        if let movieYear = Int(strYear)
        {
            let count = currentYear - movieYear

            if count > 0
            {
                return "\(count) year(s) ago"
            }
            else if count == 0
            {
                return "this year"
            }
            else
            {
                return "after \(count) year(s)"
            }
        }
        else
        {
            return "Invaild movie year"
        }
    }

    //MARK:- Collection View Methods
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return arrData.count
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: col_data.frame.size.width/2 - 20, height: 200)
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DataCell", for: indexPath) as! DataCell

        let dic = arrData.object(at: indexPath.item) as! NSDictionary

        cell.imgPoster.imageForUrlWithImage(imageURL: "\(dic.object(forKey: "Poster")!)", defaultImage: "NoImage", imageID: "\(dic.object(forKey: "imdbID")!)")
        cell.lblTitle.text = "\(dic.object(forKey: "Title")!)"
        cell.lblType.text = "\(dic.object(forKey: "Type")!)"
        cell.lblYear.text = changeYeartoTime(strYear: "\(dic.object(forKey: "Year")!)")

        return cell
    }

    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath)
    {
        if indexPath.item == arrData.count - 2 && !isWaiting && arrData.count < totalCount
        {
            isWaiting = true
            currentPage += 1
            getData()
        }
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        let dic = arrData.object(at: indexPath.item) as! NSDictionary

        let objView = self.storyboard?.instantiateViewController(withIdentifier: "DetailVC") as! DetailVC
        objView.dicData = dic
        objView.releaseYear = changeYeartoTime(strYear: "\(dic.object(forKey: "Year")!)")
        self.navigationController?.pushViewController(objView, animated: true)
    }

    //MARK:- Button Action Methods
    @IBAction func action_btnRetry(_ sender: UIButton)
    {
        self.getData()
    }

    //MARK:- APIs Methods
    func getData()
    {
        if Reachability.isConnectedToNetwork()
        {
            let webclass = WebCommunicationClass()
            webclass.aCaller = self
            webclass.getListing(currentPageNum: currentPage)
        }
        else
        {
            col_data.isHidden = true
            lblMsg.isHidden = true
            btnRetry.isHidden = false

            self.alertType(type: .okAlert, alertMSG: ErrorMsg, delegate: self)
        }
    }

    func dataDidFinishDowloading(aResponse: AnyObject?, methodname: String)
    {
        do {
            let JSONDict = try JSONSerialization.jsonObject(with: aResponse as! Data, options: .allowFragments) as! NSDictionary
            print("Response \(JSONDict)")

            let responseStatus = JSONDict.object(forKey: "Response") as! String

            if responseStatus == "True"
            {
                let responseData = (JSONDict.object(forKey: "Search") as! NSArray).arrayByReplacingNullsWithBlanks()

                btnRetry.isHidden = true
                totalCount = Int("\(JSONDict.object(forKey: "totalResults")!)")
                isWaiting = false

                arrData.addObjects(from: responseData as! [Any])

                if arrData.count > 0
                {
                    col_data.isHidden = false
                    lblMsg.isHidden = true

                    col_data.delegate = self
                    col_data.dataSource = self
                    col_data.reloadData()
                }
                else
                {
                    col_data.isHidden = true
                    lblMsg.isHidden = false
                }
            }
            else
            {
                col_data.isHidden = true
                lblMsg.isHidden = true
                btnRetry.isHidden = false

                self.alertType(type: .okAlert, alertMSG: ErrorMsg, delegate: self)
            }
        }
        catch let error as NSError
        {
            col_data.isHidden = true
            lblMsg.isHidden = true
            btnRetry.isHidden = false

            self.alertType(type: .okAlert, alertMSG: InvalidResMsg, delegate: self)
            print("Error from backend \(error)")
        }
    }

    func dataDidFail (methodname : String , error : Error)
    {
        col_data.isHidden = true
        lblMsg.isHidden = true
        btnRetry.isHidden = false

        self.alertType(type: .okAlert, alertMSG: ServerErrorMsg, delegate: self)
    }
}
